#' This is some description of this function
#' @title sendmail
#' @author Zhang_HD
#'
#' @description Input your email address and get the latest journal update.
#'
#' @param receiver receiver is your email address
#'
#' @return An email in your emailbox.
#'
#' @export
#' @examples sendmail("12345678@abc.com")



sendmail = function(receiver){
  require(rvest)
  require(stringr)
  require(mailR)

  #爬取最新一期情报学报的带摘要目录
  link <-  "http://qbxb.istic.ac.cn/CN/volumn/current_abs.shtml"
  dlink <- read_html(link)
  text <- html_nodes(dlink,"table")
  text2 <- html_text(text)
  #文本规范化处理
  text3 <- str_remove_all(text2,"[\f\n\r\t\v]")
  text4 <- text3[2]
  text5 <- str_squish(text4)
  text6 <- gsub("[[:space:]]","",text5)
  text7 <- gsub("[[:punct:]]","",text6)
  ti_ini <- unlist(str_extract_all(text6, "([0-9]{4})([\u4e00-\u9fa5]{0,})([：H])"))
  au_ini <- unlist(str_extract_all(text6,"([!])([\u4e00-\u9fa5^%&',;=?$a-zA-Z])+([D])"))
  ab_ini <- unlist(str_extract_all(text6,"([0-9]{3,})([\u4e00-\u9fa5^%&',;=-_-?$、，—。“”：；《》（）①②③④⑤0-9A-Za-z]{100,})"))
  ti <- str_sub(ti_ini,4,-2)
  ti <- str_replace(ti,"[0-9]","\n\n【题名】")
  au <- str_sub(au_ini,1,-2)
  au <- str_replace(au,"!","【作者】")
  ab <- str_sub(ab_ini,3,-8)
  ab <- str_replace(ab,"[0-9]","【摘要】")
  #得到最终的文章信息
  j_update <- str_c(ti,au,ab,sep="\n")
  #配置邮箱发送
  receiver <- receiver
  sender <- "idmr_r@163.com"
  emailSubject <- "情报学报最新当期目录"
  emailBody <- str_flatten(j_update)
  send.mail(
    from =  sender,
    to =  receiver,
    subject =  emailSubject,
    body =  emailBody,
    smtp =  list(
      host.name = "smtp.163.com",
      port =  465,
      user.name  =  sender,
      passwd =  "IIADGPAFLVNTOUJL",
      ssl =  TRUE
    ),
    authenticate = TRUE,
    send =  TRUE,
    encoding  =  "utf-8"
  )
}
